"""
panel_auditoria.py — Panel de auditoría de rendimiento del bot de predicción macro.

Ejecutar con:
    streamlit run panel_auditoria.py

Sin un CSV propio, el panel arranca en MODO DEMOSTRACIÓN con datos sintéticos
(generados con generar_datos_demo.py) solo para explorar la interfaz; esos
números NO representan el rendimiento real del bot.

Formato del CSV de tu bot:
    fecha_prediccion, fecha_objetivo, activo, direccion_predicha, direccion_real,
    [horizonto], [prob_bajista]
Direcciones admitidas: alcista / neutral / bajista (también bull/flat/bear, etc.).
Una señal sin direccion_real cuenta como PENDIENTE, no como acierto ni error.
"""

from pathlib import Path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

import auditoria as au

ARCHIVO_DEMO = Path(__file__).parent / "predicciones_demo.csv"
st.set_page_config(page_title="Auditoría del bot de predicción", layout="wide")


# ------------------------------------------------------------------ utilidades de formato
def pct(valor):
    if valor is None or (isinstance(valor, float) and np.isnan(valor)):
        return "N/D"
    return f"{valor * 100:.1f} %"


# ------------------------------------------------------------------ carga de datos
st.title("Panel de auditoría de rendimiento — bot de predicción macro")
st.caption(
    "Audita la precisión direccional del bot: aciertos, matriz de confusión, "
    "falsos positivos bajistas y evolución histórica. La clase positiva es **bajista**."
)

with st.sidebar:
    st.header("Datos")
    subido = st.file_uploader("CSV de predicciones del bot", type="csv",
                              help="Columnas: fecha_prediccion, fecha_objetivo, activo, "
                                   "direccion_predicha, direccion_real (+ opcionales horizonte, prob_bajista)")
    demo = subido is None and ARCHIVO_DEMO.exists()
    if subido is not None:
        st.success("CSV cargado.")
    elif demo:
        st.warning("MODO DEMOSTRACIÓN: datos sintéticos, no son resultados reales del bot.")

try:
    datos = au.cargar_predicciones(subido if subido is not None else ARCHIVO_DEMO)
except ValueError as e:
    st.error(f"No se pudo leer el archivo: {e}")
    st.stop()

if datos.evaluadas.empty and datos.pendientes.empty:
    st.error("El archivo no contiene señales utilizables.")
    st.stop()

for problema in datos.problemas:
    st.info(problema)

st.sidebar.metric("Señales evaluadas", len(datos.evaluadas))
st.sidebar.metric("Señales pendientes", len(datos.pendientes))
st.sidebar.metric("Filas excluidas", len(datos.invalidas))
st.sidebar.metric("Duplicadas descartadas", datos.n_duplicadas)

# ------------------------------------------------------------------ filtros
df_todas = pd.concat([datos.evaluadas, datos.pendientes], ignore_index=True)
with st.sidebar:
    st.header("Filtros")
    activos = ["Todos"] + sorted(df_todas["activo"].unique())
    activo_sel = st.selectbox("Activo", activos)
    horizontos = ["Todos"]
    if "horizonte" in df_todas.columns:
        horizontos += sorted(h for h in df_todas["horizonte"].dropna().unique() if str(h) != "nan")
    horizonte_sel = st.selectbox("Horizonte", horizontos)
    rango_fechas = st.date_input(
        "Rango de fecha objetivo",
        value=(df_todas["fecha_objetivo"].min().date(), df_todas["fecha_objetivo"].max().date()),
        min_value=df_todas["fecha_objetivo"].min().date(),
        max_value=df_todas["fecha_objetivo"].max().date(),
    )
    ventana_movil = st.slider("Ventana de exactitud móvil", 5, 100, 20, 5)

df_eval = datos.evaluadas.copy()
df_pend = datos.pendientes.copy()
if activo_sel != "Todos":
    df_eval = df_eval[df_eval["activo"] == activo_sel]
    df_pend = df_pend[df_pend["activo"] == activo_sel]
if horizonte_sel != "Todos" and "horizonte" in df_todas.columns:
    df_eval = df_eval[df_eval["horizonte"] == horizonte_sel]
    df_pend = df_pend[df_pend["horizonte"] == horizonte_sel]
if len(rango_fechas) == 2:
    ini = pd.Timestamp(rango_fechas[0])
    # límite superior exclusivo: una señal del último día a las 15:00 sigue incluida
    fin_exclusivo = pd.Timestamp(rango_fechas[1]) + pd.Timedelta(days=1)
    df_eval = df_eval[(df_eval["fecha_objetivo"] >= ini) & (df_eval["fecha_objetivo"] < fin_exclusivo)]
    df_pend = df_pend[(df_pend["fecha_objetivo"] >= ini) & (df_pend["fecha_objetivo"] < fin_exclusivo)]

if df_eval.empty:
    st.warning("No hay señales evaluadas con los filtros seleccionados.")
    if not df_pend.empty:
        st.dataframe(df_pend[["fecha_prediccion", "fecha_objetivo", "activo", "direccion_predicha"]])
    st.stop()

m = au.calcular_metricas(df_eval)
b = m.bajista

# ------------------------------------------------------------------ KPIs principales
st.subheader("Resumen general")
c1, c2, c3, c4 = st.columns(4)
with c1:
    st.metric("Exactitud direccional", pct(m.exactitud_direccional),
              help=f"Aciertos / señales evaluadas (n={m.n_evaluadas}). "
                   f"Referencia trivial (siempre predecir la clase mayoritaria): {pct(m.referencia_mayoritaria)}.")
with c2:
    st.metric("Exactitud balanceada", pct(m.exactitud_balanceada),
              help="Promedio del recall de cada clase real; penaliza aciertos concentrados en una sola clase.")
with c3:
    st.metric("Señales evaluadas", m.n_evaluadas,
              help=f"Otras {len(df_pend)} pendientes de resultado y {len(datos.invalidas)} excluidas por datos inválidos.")
with c4:
    delta = None
    if m.referencia_mayoritaria is not None and m.exactitud_direccional is not None:
        delta = f"{(m.exactitud_direccional - m.referencia_mayoritaria) * 100:+.1f} pp"
    st.metric("Ventaja vs clase mayoritaria", delta,
              help="Puntos porcentuales por encima (o por debajo) de predecir siempre la clase más frecuente.")

st.subheader("Auditoría de movimientos bajistas")
st.caption(
    "TP: predijo bajista y bajó · FP: predijo bajista y no bajó (falso positivo) · "
    "FN: no predijo bajista y bajó (bajada no detectada) · TN: no predijo bajista y no bajó."
)
c1, c2, c3, c4 = st.columns(4)
with c1:
    st.metric("Precisión bajista", pct(b.precision),
              help=f"TP/(TP+FP) = {b.tp}/({b.tp}+{b.fp}). De las señales bajistas, cuántas acertaron.")
with c2:
    st.metric("Detección de bajadas (recall)", pct(b.recall),
              help=f"TP/(TP+FN) = {b.tp}/({b.tp}+{b.fn}). De las bajadas reales, cuántas detectó.")
with c3:
    st.metric("Tasa de falsos positivos", pct(b.tasa_falsos_positivos),
              help=f"FP/(FP+TN) = {b.fp}/({b.fp}+{b.tn}). Señales bajistas falsas sobre todo lo que no bajó.")
with c4:
    st.metric("F1 bajista", pct(b.f1),
              help="Media armónica de precisión y recall bajistas.")

t1, t2, t3, t4 = st.columns(4)
t1.metric("TP (acierto bajista)", b.tp)
t2.metric("FP (falso positivo)", b.fp)
t3.metric("FN (bajada no detectada)", b.fn)
t4.metric("TN (correctamente no bajista)", b.tn)

# ------------------------------------------------------------------ matriz de confusión
st.subheader("Matriz de confusión")
st.caption("Filas = dirección real · Columnas = dirección predicha. La diagonal son los aciertos.")

clases = [c for c in au.CLASES if c in m.matriz.index or c in m.matriz.columns]
conteos = m.matriz.reindex(index=clases, columns=clases, fill_value=0)
norm = conteos.div(conteo_real := conteos.sum(axis=1).replace(0, np.nan), axis=0)

tab1, tab2 = st.tabs(["Conteos", "Normalizada por dirección real"])
for tab, valores, fmt in ((tab1, conteos, None), (tab2, norm, "texto")):
    fig = go.Figure(go.Heatmap(
        z=valores.values,
        x=[f"Pred: {c}" for c in conteos.columns],
        y=[f"Real: {c}" for c in conteos.index],
        text=valores.values if fmt is None else [[pct(v) for v in fila] for fila in valores.values],
        texttemplate="%{text}",
        colorscale="RdYlGn" if fmt is None else "Blues",
        zmid=None if fmt is None else 0.5,
        reversescale=False,
    ))
    fig.update_layout(height=380, margin=dict(l=10, r=10, t=10, b=10), xaxis_title=None)
    tab.plotly_chart(fig, width="stretch")

with st.expander("Ver tabla de conteos"):
    st.dataframe(conteos)
    st.dataframe(norm)

# ------------------------------------------------------------------ métricas por clase
st.subheader("Métricas por clase")
st.dataframe(
    m.por_clase.style.format({
        "precision": pct, "recall": pct, "f1": pct,
    }),
    width="stretch",
)

# ------------------------------------------------------------------ histórico
st.subheader("Rendimiento histórico")
st.caption("Agrupado por mes según la fecha del resultado (fecha_objetivo).")

periodos = au.metricas_por_periodo(df_eval, freq="MS")
fig = go.Figure()
fig.add_trace(go.Bar(
    x=periodos.index, y=periodos["exactitud"], name="Exactitud mensual",
    marker_color="rgba(31,119,180,0.55)", yaxis="y",
))
if len(periodos) > 1:
    fig.add_trace(go.Scatter(
        x=periodos.index, y=au.exactitud_acumulada(periodos),
        name="Exactitud acumulada (ponderada)", line=dict(color="#1f77b4", width=3),
    ))
if m.referencia_mayoritaria is not None:
    fig.add_hline(y=m.referencia_mayoritaria, line_dash="dash", line_color="gray",
                  annotation_text=f"Referencia mayoritaria {pct(m.referencia_mayoritaria)}")
fig.update_layout(height=380, yaxis_tickformat=".0%", yaxis_title="Exactitud",
                  legend=dict(orientation="h", y=1.12), margin=dict(l=10, r=10, t=30, b=10))
st.plotly_chart(fig, width="stretch")

c1, c2 = st.columns(2)
with c1:
    fig = go.Figure()
    fig.add_trace(go.Bar(x=periodos.index, y=periodos["precision_bajista"], name="Precisión bajista",
                         marker_color="rgba(214,39,40,0.55)"))
    fig.add_trace(go.Bar(x=periodos.index, y=periodos["deteccion_bajadas"], name="Detección de bajadas",
                         marker_color="rgba(44,160,44,0.55)"))
    fig.update_layout(barmode="group", height=340, yaxis_tickformat=".0%", yaxis_title="Tasa",
                      legend=dict(orientation="h", y=1.12), margin=dict(l=10, r=10, t=30, b=10))
    st.plotly_chart(fig, width="stretch")
with c2:
    fig = go.Figure()
    fig.add_trace(go.Bar(x=periodos.index, y=periodos["falsos_positivos_bajista"],
                         name="Falsos positivos bajistas", marker_color="#d62728"))
    fig.add_trace(go.Bar(x=periodos.index, y=periodos["observaciones"], name="Observaciones",
                         marker_color="rgba(150,150,150,0.5)", yaxis="y2"))
    fig.update_layout(height=340, legend=dict(orientation="h", y=1.12),
                      margin=dict(l=10, r=10, t=30, b=10),
                      yaxis2=dict(overlaying="y", side="right", showgrid=False))
    st.plotly_chart(fig, width="stretch")

st.subheader(f"Exactitud móvil (ventana de {ventana_movil} señales)")
movil = au.exactitud_movil(df_eval, ventana=ventana_movil)
fig = go.Figure()
fig.add_trace(go.Scatter(x=movil.index, y=movil["exactitud_movil"], name="Exactitud móvil",
                          line=dict(color="#1f77b4")))
fig.add_trace(go.Scatter(x=movil.index, y=movil["aciertos_acumulados"], name="Exactitud acumulada",
                         line=dict(color="#ff7f0e", dash="dot")))
if m.referencia_mayoritaria is not None:
    fig.add_hline(y=m.referencia_mayoritaria, line_dash="dash", line_color="gray")
fig.update_layout(height=340, yaxis_tickformat=".0%", legend=dict(orientation="h", y=1.12),
                  margin=dict(l=10, r=10, t=30, b=10))
st.plotly_chart(fig, width="stretch")

# ------------------------------------------------------------------ calibración (opcional)
calib = au.calibracion_probabilidades(df_eval)
if calib is not None and len(calib) > 0:
    with st.expander("Calibración de prob_bajista (opcional)", expanded=False):
        fig = go.Figure()
        fig.add_trace(go.Bar(x=calib["prob_media"].round(2).astype(str), y=calib["tasa_bajada_real"],
                             name="Bajada real observada", marker_color="rgba(214,39,40,0.6)"))
        fig.add_trace(go.Scatter(x=calib["prob_media"].round(2).astype(str), y=calib["prob_media"],
                                 name="Probabilidad emitida", line=dict(color="#1f77b4", dash="dot")))
        fig.update_layout(height=300, yaxis_tickformat=".0%", legend=dict(orientation="h", y=1.15),
                          margin=dict(l=10, r=10, t=30, b=10))
        st.plotly_chart(fig, width="stretch")
        st.dataframe(calib.style.format({
            "prob_media": pct, "tasa_bajada_real": pct,
        }), width="stretch")

# ------------------------------------------------------------------ señales pendientes y descargas
if not df_pend.empty:
    with st.expander(f"Señales pendientes de resultado ({len(df_pend)})", expanded=False):
        st.dataframe(df_pend[["fecha_prediccion", "fecha_objetivo", "activo", "direccion_predicha"]],
                     width="stretch")

st.subheader("Descargas")
c1, c2, c3 = st.columns(3)
c1.download_button("Métricas por clase (CSV)", m.por_clase.to_csv().encode("utf-8"),
                   "metricas_por_clase.csv", "text/csv")
c2.download_button("Métricas por mes (CSV)", periodos.to_csv().encode("utf-8"),
                  "metricas_por_mes.csv", "text/csv")
c3.download_button("Señales evaluadas (CSV)",
                   df_eval.to_csv(index=False).encode("utf-8"),
                   "senales_evaluadas.csv", "text/csv")

st.divider()
st.caption(
    "Auditoría de calidad direccional: indica si el bot acierta o falla la dirección, "
    "no si la estrategia es rentable (para eso haría falta definir ejecución, exposición y costos)."
)
