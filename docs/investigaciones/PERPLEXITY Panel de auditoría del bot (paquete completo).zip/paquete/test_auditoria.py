"""
test_auditoria.py — Pruebas del módulo de cálculo.

Ejecutar: python test_auditoria.py
Cubre: caso de referencia (TP=3, FP=1, FN=2, TN=4), clases ausentes, pendientes,
CSV inválido, métricas por período, exactitud móvil y calibración.
"""

import numpy as np
import pandas as pd

import auditoria as au

ERRORES = 0


def comprobar(nombre, obtenido, esperado, tolerancia=1e-9):
    global ERRORES
    ok = (
        abs(obtenido - esperado) <= tolerancia
        if isinstance(obtenido, float) and isinstance(esperado, float)
        else obtenido == esperado
    )
    if not ok:
        ERRORES += 1
        print(f"FALLO  {nombre}: obtenido={obtenido!r} esperado={esperado!r}")
    else:
        print(f"ok     {nombre} = {obtenido!r}")


def marco(filas):
    return pd.DataFrame(filas, columns=["fecha_prediccion", "fecha_objetivo", "activo",
                                        "direccion_predicha", "direccion_real"])


def caso_referencia():
    """TP=3, FP=1, FN=2, TN=4 → exactitud 70 %, precisión 75 %, recall 60 %, FPR 20 %."""
    filas = []
    filas += [("2026-01-01", "2026-01-02", "X", "bajista", "bajista")] * 3      # TP
    filas += [("2026-01-01", "2026-01-02", "X", "bajista", "alcista")] * 1      # FP
    filas += [("2026-01-01", "2026-01-02", "X", "alcista", "bajista")] * 2      # FN
    filas += [("2026-01-01", "2026-01-02", "X", "alcista", "alcista")] * 4      # TN
    m = au.calcular_metricas(marco(filas))
    comprobar("TP", m.bajista.tp, 3)
    comprobar("FP", m.bajista.fp, 1)
    comprobar("FN", m.bajista.fn, 2)
    comprobar("TN", m.bajista.tn, 4)
    comprobar("exactitud", m.exactitud_direccional, 0.70)
    comprobar("precision bajista", m.bajista.precision, 0.75)
    comprobar("recall bajista", m.bajista.recall, 0.60)
    comprobar("tasa falsos positivos", m.bajista.tasa_falsos_positivos, 0.20)
    comprobar("F1 bajista", m.bajista.f1, 2 * 0.75 * 0.60 / 1.35)


def caso_clases_ausentes():
    """Sin clase neutral: la matriz debe restringirse a las clases presentes."""
    filas = [("2026-01-01", "2026-01-02", "X", "bajista", "bajista"),
             ("2026-01-01", "2026-01-02", "X", "alcista", "alcista")]
    m = au.calcular_metricas(marco(filas))
    comprobar("exactitud sin neutral", m.exactitud_direccional, 1.0)
    comprobar("clases matriz", list(m.matriz.index), ["alcista", "bajista"])
    comprobar("FPR sin FP", m.bajista.tasa_falsos_positivos, 0.0)


def caso_pendientes():
    """Señales sin resultado real quedan como pendientes, no afectan métricas."""
    csv = "fecha_prediccion,fecha_objetivo,activo,direccion_predicha,direccion_real\n"
    csv += "2026-01-01,2026-01-02,X,bajista,bajista\n"
    csv += "2026-01-05,2026-01-06,X,bajista,\n"          # pendiente
    csv += "2026-01-05,2026-01-06,X,alcista,desconocida\n"  # real no reconocida → excluida
    datos = au.cargar_predicciones(pd.io.common.StringIO(csv))
    comprobar("evaluadas", len(datos.evaluadas), 1)
    comprobar("pendientes", len(datos.pendientes), 1)
    comprobar("invalidas", len(datos.invalidas), 1)
    m = au.calcular_metricas(datos.evaluadas)
    comprobar("exactitud con pendientes", m.exactitud_direccional, 1.0)


def caso_csv_invalido():
    """Faltan columnas requeridas → ValueError claro."""
    csv = "fecha,activo,signal\n2026-01-01,X,bajista\n"
    try:
        au.cargar_predicciones(pd.io.common.StringIO(csv))
        comprobar("CSV inválido lanza error", False, True)
    except ValueError as e:
        comprobar("CSV inválido lanza error", "Faltan columnas" in str(e), True)


def caso_vacio():
    """DataFrame vacío: métricas en N/D (None), sin excepciones."""
    m = au.calcular_metricas(pd.DataFrame())
    comprobar("n_evaluadas vacío", m.n_evaluadas, 0)
    comprobar("exactitud vacía", m.exactitud_direccional is None, True)
    comprobar("precision vacía", m.bajista.precision is None, True)


def caso_denominador_cero():
    """Sin bajadas reales: recall N/D; sin señales bajistas: precisión N/D pero FPR 0 % (FP=0)."""
    filas = [("2026-01-01", "2026-01-02", "X", "alcista", "alcista"),
             ("2026-01-01", "2026-01-02", "X", "alcista", "neutral")]
    m = au.calcular_metricas(marco(filas))
    comprobar("precision N/D", m.bajista.precision is None, True)
    comprobar("tasa FP 0 % (FP=0, TN=2)", m.bajista.tasa_falsos_positivos, 0.0)
    comprobar("recall N/D sin bajadas reales", m.bajista.recall is None, True)


def caso_periodo_y_movil():
    filas = []
    base = pd.Timestamp("2026-01-01")
    for i in range(60):
        real = "bajista" if i % 3 == 0 else "alcista"
        pred = "bajista" if i % 3 == 0 and i < 45 else "alcista"  # acierta 15/20 bajadas
        objetivo = base + pd.Timedelta(days=i)
        filas.append((str(objetivo.date()), str((objetivo + pd.Timedelta(days=1)).date()),
                      "X", pred, real))
    df = marco(filas)
    per = au.metricas_por_periodo(df, freq="MS")
    comprobar("periodos cubiertos", len(per) >= 2, True)
    mov = au.exactitud_movil(df, ventana=10)
    comprobar("exactitud móvil filas", len(mov), 60)
    comprobar("aciertos acumulados inicio", mov["aciertos_acumulados"].iloc[0], 1.0)


def caso_calibracion():
    df = pd.DataFrame({
        "fecha_prediccion": ["2026-01-01"] * 4,
        "fecha_objetivo": ["2026-01-02"] * 4,
        "activo": ["X"] * 4,
        "direccion_predicha": ["bajista", "alcista", "bajista", "alcista"],
        "direccion_real": ["bajista", "alcista", "alcista", "alcista"],
        "prob_bajista": [0.9, 0.1, 0.8, 0.2],
    })
    df["fecha_prediccion"] = pd.to_datetime(df["fecha_prediccion"])
    df["fecha_objetivo"] = pd.to_datetime(df["fecha_objetivo"])
    df["predicha"] = df["direccion_predicha"]
    df["real"] = df["direccion_real"]
    cal = au.calibracion_probabilidades(df, n_bins=2)
    comprobar("calibración bins", len(cal), 2)
    bin_alto = cal[cal["prob_media"] > 0.5].iloc[0]
    bin_bajo = cal[cal["prob_media"] <= 0.5].iloc[0]
    comprobar("tasa real bin alto", bin_alto["tasa_bajada_real"], 0.5)  # 0.9 acertó, 0.8 fue falso positivo
    comprobar("tasa real bin bajo", bin_bajo["tasa_bajada_real"], 0.0)


def caso_normalizacion():
    comprobar("bull→alcista", au.normalizar_direccion("BULL"), "alcista")
    comprobar("Bear!→bajista con tilde", au.normalizar_direccion("Caída"), "bajista")
    comprobar("vacío→None", au.normalizar_direccion(""), None)
    comprobar("nan→None", au.normalizar_direccion(float("nan")), None)
    comprobar("texto raro→None", au.normalizar_direccion("quizás"), None)


def caso_f1_cero():
    """TP=0, FP=1, FN=1: F1 debe ser 0 %, no N/D."""
    m = au.MetricasBajista(tp=0, fp=1, fn=1, tn=5)
    comprobar("F1 cero con errores", m.f1, 0.0)
    m2 = au.MetricasBajista(tp=0, fp=0, fn=0, tn=5)
    comprobar("F1 N/D sin casos", m2.f1 is None, True)


def caso_exactitud_acumulada():
    """Mes 1: 1/1 aciertos; mes 2: 0/9. La acumulada debe terminar en 10 %, no 50 %."""
    periodos = pd.DataFrame({
        "exactitud": [1.0, 0.0],
        "observaciones": [1, 9],
    }, index=pd.to_datetime(["2026-01-01", "2026-02-01"]))
    acum = au.exactitud_acumulada(periodos)
    comprobar("acumulada mes 1", acum.iloc[0], 1.0)
    comprobar("acumulada final ponderada", acum.iloc[-1], 0.10)


def caso_exclusiones_y_duplicados():
    """Las filas inválidas se conservan con motivo; duplicados solo si coincide también horizonte."""
    csv = (
        "fecha_prediccion,fecha_objetivo,activo,horizonte,direccion_predicha,direccion_real\n"
        "2026-01-01 10:00,2026-01-02,X,1d,bajista,bajista\n"
        "2026-01-01 10:00,2026-01-02,X,1w,bajista,bajista\n"      # distinto horizonte: NO duplicada
        "2026-01-01 10:00,2026-01-02,X,1d,bajista,bajista\n"      # duplicada exacta
        "fecha_invalida,2026-01-02,X,1d,bajista,bajista\n"       # fecha mala → inválida
        "2026-01-03 10:00,2026-01-02,X,1d,bajista,bajista\n"     # predicción posterior al objetivo → inválida
    )
    datos = au.cargar_predicciones(pd.io.common.StringIO(csv))
    comprobar("evaluadas", len(datos.evaluadas), 2)
    comprobar("duplicadas descartadas", datos.n_duplicadas, 1)
    comprobar("invalidas conservadas", len(datos.invalidas), 2)
    comprobar("motivo fecha", "fecha" in str(datos.invalidas["motivo_invalida"].iloc[0]), True)


def caso_no_vencidas():
    """Señal con fecha_objetivo futura (incluso con resultado informado) queda como pendiente."""
    csv = (
        "fecha_prediccion,fecha_objetivo,activo,direccion_predicha,direccion_real\n"
        "2030-01-01,2030-01-08,X,bajista,bajista\n"
        "2026-01-01,2026-01-02,X,bajista,bajista\n"
    )
    datos = au.cargar_predicciones(pd.io.common.StringIO(csv))
    comprobar("futuras evaluadas", len(datos.evaluadas), 1)
    comprobar("futuras pendientes", len(datos.pendientes), 1)


def caso_corte_horario():
    """El corte usa la hora exacta: objetivo 15:00 auditado a las 16:00 es vencido; 17:00 no."""
    csv = (
        "fecha_prediccion,fecha_objetivo,activo,direccion_predicha,direccion_real\n"
        "2026-10-19,2026-10-20 15:00,X,bajista,bajista\n"
        "2026-10-19,2026-10-20 17:00,X,bajista,bajista\n"
    )
    datos = au.cargar_predicciones(
        pd.io.common.StringIO(csv), fecha_corte="2026-10-20 16:00"
    )
    comprobar("objetivo 15:00 evaluada", len(datos.evaluadas), 1)
    comprobar("objetivo 17:00 pendiente", len(datos.pendientes), 1)


if __name__ == "__main__":
    caso_referencia()
    caso_clases_ausentes()
    caso_pendientes()
    caso_csv_invalido()
    caso_vacio()
    caso_denominador_cero()
    caso_periodo_y_movil()
    caso_calibracion()
    caso_normalizacion()
    caso_f1_cero()
    caso_exactitud_acumulada()
    caso_exclusiones_y_duplicados()
    caso_no_vencidas()
    caso_corte_horario()
    print("\n" + ("TODAS LAS PRUEBAS PASARON" if ERRORES == 0 else f"{ERRORES} PRUEBAS FALLARON"))
    raise SystemExit(1 if ERRORES else 0)
