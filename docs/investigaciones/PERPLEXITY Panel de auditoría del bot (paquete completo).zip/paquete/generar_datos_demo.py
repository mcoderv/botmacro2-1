"""
generar_datos_demo.py — Crea un CSV sintético de predicciones para explorar el panel.

El bot simulado tiene un sesgo levemente optimista en detectar bajadas, con racha
de sobre-venta de señales bajistas (falsos positivos) y etapas de acierto irregular.
Ejecutar: python generar_datos_demo.py  [ruta_salida.csv]
"""

import sys
from pathlib import Path

import numpy as np
import pandas as pd

RNG = np.random.default_rng(42)

ACTIVOS = ["BTCUSDT", "ETHUSDT", "SP500", "USDCOP"]
HORIZONTES = ["1d", "1w"]
CLASES = ["alcista", "neutral", "bajista"]


def generar(n=900, ruta="predicciones_demo.csv"):
    filas = []
    # etapa de "calibración": acierto mediocre al inicio, mejora después
    destreza_base = np.concatenate([
        np.full(int(n * 0.3), 0.42),   # arranque flojo
        np.full(int(n * 0.5), 0.55),   # etapa estable
        np.full(n - int(n * 0.3) - int(n * 0.5), 0.50),  # decaimiento final
    ])
    fecha = pd.Timestamp("2025-01-06")
    for i in range(n):
        fecha_prediccion = fecha + pd.Timedelta(hours=8 * (i // 3))
        horizonte = HORIZONTES[i % 2]
        fecha_objetivo = fecha_prediccion + (pd.Timedelta(days=1) if horizonte == "1d" else pd.Timedelta(days=7))
        activo = ACTIVOS[i % len(ACTIVOS)]

        prob_bajista = float(RNG.uniform(0.05, 0.6))
        if prob_bajista > 0.45:
            predicha = "bajista"
        elif prob_bajista < 0.2:
            predicha = "alcista"
        else:
            predicha = "neutral"

        # el mercado real es alcista-sesgado; el bot sobre-vende bajistas (falsos positivos)
        real = RNG.choice(CLASES, p=[0.45, 0.25, 0.30])
        destreza = destreza_base[i]
        if predicha == "bajista":
            # las señales bajistas aciertan más de lo que sugiere la probabilidad
            real = "bajista" if RNG.random() < min(0.5 + destreza * 0.3, 0.75) else real
        elif predicha == "alcista" and RNG.random() < destreza:
            real = "alcista"

        filas.append({
            "fecha_prediccion": fecha_prediccion,
            "fecha_objetivo": fecha_objetivo,
            "activo": activo,
            "horizonte": horizonte,
            "direccion_predicha": predicha,
            "direccion_real": real if RNG.random() > 0.04 else "",  # 4 % pendientes
            "prob_bajista": round(prob_bajista, 3),
        })
    df = pd.DataFrame(filas)
    df.to_csv(ruta, index=False)
    print(f"Generadas {n} señales sintéticas en {ruta}")
    print(df.head().to_string())


if __name__ == "__main__":
    ruta = sys.argv[1] if len(sys.argv) > 1 else "predicciones_demo.csv"
    generar(ruta=ruta)
