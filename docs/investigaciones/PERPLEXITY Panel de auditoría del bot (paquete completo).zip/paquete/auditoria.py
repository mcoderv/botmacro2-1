"""
auditoria.py — Núcleo de cálculo del panel de auditoría de rendimiento.

Audita la calidad direccional de las predicciones de un bot de trading macro:
precisión direccional, matriz de confusión, falsos positivos y tasas de acierto
en movimientos bajistas (clase positiva = "bajista").

Contrato de entrada (CSV):
    fecha_prediccion   : fecha en que el bot emitió la señal       (obligatoria)
    fecha_objetivo     : fecha del resultado que se predijo          (obligatoria)
    activo             : instrumento o par                         (obligatoria)
    direccion_predicha : "alcista" | "bajista" | "neutral"           (obligatoria)
    direccion_real     : "alcista" | "bajista" | "neutral" o vacío   (obligatoria en formato)
    horizonte          : horizonte de la predicción (opcional)
    prob_bajista       : probabilidad de bajada emitida, 0-1 (opcional)

Reglas:
    - Una fila sin direccion_real es PENDIENTE (no es acierto ni error).
    - Direcciones fuera del vocabulario se reportan como filas inválidas.
    - Con clase positiva "bajista":
        TP: predijo bajista y fue bajista
        FP: predijo bajista y NO fue bajista (falso positivo bajista)
        FN: no predijo bajista y fue bajista (bajada no detectada)
        TN: no predijo bajista y no fue bajista
"""

from __future__ import annotations

import unicodedata
from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import pandas as pd

CLASES = ("alcista", "neutral", "bajista")
CLASE_POSITIVA = "bajista"

SINONIMOS = {
    "alcista": "alcista", "alza": "alcista", "subida": "alcista", "bull": "alcista",
    "long": "alcista", "compra": "alcista", "up": "alcista", "1": "alcista",
    "neutral": "neutral", "neutro": "neutral", "plano": "neutral", "flat": "neutral",
    "lateral": "neutral", "0": "neutral",
    "bajista": "bajista", "baja": "bajista", "caida": "bajista", "bear": "bajista",
    "short": "bajista", "venta": "bajista", "down": "bajista", "-1": "bajista",
}

COLUMNAS_REQUERIDAS = [
    "fecha_prediccion", "fecha_objetivo", "activo",
    "direccion_predicha", "direccion_real",
]


# ----------------------------------------------------------------------------- utilidades
def _quitar_tildes(texto: str) -> str:
    return "".join(
        c for c in unicodedata.normalize("NFD", texto) if unicodedata.category(c) != "Mn"
    )


def normalizar_direccion(valor) -> Optional[str]:
    """Normaliza una dirección a alcista/neutral/bajista. None si es inválida o vacía."""
    if valor is None or (isinstance(valor, float) and np.isnan(valor)):
        return None
    texto = _quitar_tildes(str(valor).strip().lower())
    if texto == "" or texto.lower() in ("nan", "none", "null"):
        return None
    return SINONIMOS.get(texto)


def _pct(valor: Optional[float]) -> str:
    """Formatea una proporción como porcentaje; 'N/D' si no es calculable."""
    if valor is None or (isinstance(valor, float) and np.isnan(valor)):
        return "N/D"
    return f"{valor * 100:.1f} %"


# ----------------------------------------------------------------------------- carga
@dataclass
class DatosCargados:
    """Resultado de la carga y validación del CSV de predicciones."""
    evaluadas: pd.DataFrame = field(default_factory=pd.DataFrame)   # con resultado real conocido y vencidas
    pendientes: pd.DataFrame = field(default_factory=pd.DataFrame)  # señal sin resultado aún o no vencida
    invalidas: pd.DataFrame = field(default_factory=pd.DataFrame)    # filas con datos inválidos (columna motivo_invalida)
    n_duplicadas: int = 0
    problemas: list[str] = field(default_factory=list)


def cargar_predicciones(ruta_o_dataframe, fecha_corte=None) -> DatosCargados:
    """Lee el CSV (ruta o DataFrame), normaliza columnas y separa evaluadas / pendientes / inválidas.

    fecha_corte: fecha y hora hasta la que un resultado puede considerarse vencido. Por
    defecto, el momento exacto de la auditoría (una señal con objetivo hoy a las 15:00
    auditada a las 16:00 está vencida; otra con objetivo a las 17:00 queda pendiente).
    Una señal con fecha_objetivo posterior a la fecha de corte queda como PENDIENTE.
    """
    df = pd.read_csv(ruta_o_dataframe) if not isinstance(ruta_o_dataframe, pd.DataFrame) else ruta_o_dataframe.copy()
    problemas: list[str] = []

    df.columns = [str(c).strip().lower().replace(" ", "_") for c in df.columns]
    faltan = [c for c in COLUMNAS_REQUERIDAS if c not in df.columns]
    if faltan:
        raise ValueError(f"Faltan columnas requeridas: {', '.join(faltan)}")

    fecha_corte = pd.Timestamp.now() if fecha_corte is None else pd.Timestamp(fecha_corte)

    for col in ("fecha_prediccion", "fecha_objetivo"):
        df[col] = pd.to_datetime(df[col], errors="coerce")

    df["activo"] = df["activo"].astype(str).str.strip()
    if "horizonte" in df.columns:
        df["horizonte"] = df["horizonte"].astype(str).str.strip()
    if "prob_bajista" in df.columns:
        df["prob_bajista"] = pd.to_numeric(df["prob_bajista"], errors="coerce")

    df["predicha"] = df["direccion_predicha"].map(normalizar_direccion)
    df["real"] = df["direccion_real"].map(normalizar_direccion)

    fechas_malas = df["fecha_prediccion"].isna() | df["fecha_objetivo"].isna()
    predicha_mala = df["predicha"].isna()
    activo_vacio = df["activo"].isin(["", "nan", "None"])
    prediccion_posterior = df["fecha_prediccion"] > df["fecha_objetivo"]

    df["motivo_invalida"] = pd.NA
    df.loc[fechas_malas, "motivo_invalida"] = "fecha_prediccion o fecha_objetivo inválida"
    df.loc[predicha_mala & df["motivo_invalida"].isna(), "motivo_invalida"] = "direccion_predicha no reconocida"
    df.loc[activo_vacio & df["motivo_invalida"].isna(), "motivo_invalida"] = "activo vacío"
    df.loc[prediccion_posterior & df["motivo_invalida"].isna(), "motivo_invalida"] = "fecha_prediccion posterior a fecha_objetivo"
    df.loc[df["direccion_real"].notna() & df["real"].isna(), "motivo_invalida"] = "direccion_real no reconocida (debe ser alcista/bajista/neutral)"

    mascara_invalida = df["motivo_invalida"].notna()
    if mascara_invalida.any():
        problemas.append(
            f"{int(mascara_invalida.sum())} filas inválidas y excluidas (ver columna motivo_invalida): "
            + "; ".join(f"{m}: {int((df['motivo_invalida'] == m).sum())}" for m in df.loc[mascara_invalida, "motivo_invalida"].unique())
        )

    validas = df[~mascara_invalida].copy()

    # Duplicados: misma señal (fecha, activo, predicción y horizonte si existe) repetida.
    clave = ["fecha_prediccion", "fecha_objetivo", "activo", "direccion_predicha"]
    if "horizonte" in validas.columns:
        clave.append("horizonte")
    dup = validas.duplicated(subset=clave, keep="first")
    n_duplicadas = int(dup.sum())
    if n_duplicadas:
        problemas.append(f"{n_duplicadas} filas duplicadas (misma señal repetida) descartadas.")
    validas = validas[~dup].copy()

    # Pendientes: sin resultado real aún, o con fecha objetivo aún no vencida a la fecha de corte.
    no_vencida = validas["fecha_objetivo"] > fecha_corte
    sin_resultado = validas["real"].isna()
    pendiente_mask = sin_resultado | no_vencida
    if no_vencida.any():
        problemas.append(
            f"{int(no_vencida.sum())} señales aún NO VENCIDAS a la fecha de corte: tratadas como pendientes, no evaluadas."
        )
    if (no_vencida & ~sin_resultado).any():
        problemas.append(
            f"{int((no_vencida & ~sin_resultado).sum())} señales no vencidas ya traen resultado: se guardan como pendientes."
        )
    if (sin_resultado & ~no_vencida).any():
        problemas.append(
            f"{int((sin_resultado & ~no_vencida).sum())} señales PENDIENTES (sin resultado real aún): excluidas de las métricas."
        )

    datos = DatosCargados()
    datos.evaluadas = validas[~pendiente_mask].copy()
    datos.pendientes = validas[pendiente_mask].copy()
    datos.invalidas = df[mascara_invalida].copy()
    datos.n_duplicadas = n_duplicadas
    datos.problemas = problemas
    return datos


# ----------------------------------------------------------------------------- métricas
@dataclass
class MetricasBajista:
    """Métricas con la clase positiva = bajista (movimiento bajista es lo que se quiere detectar)."""
    tp: int = 0  # predijo bajista y bajó (acierto bajista)
    fp: int = 0  # predijo bajista y NO bajó (falso positivo bajista)
    fn: int = 0  # no predijo bajista y bajó (bajada no detectada)
    tn: int = 0  # no predijo bajista y no bajó

    precision: Optional[float] = None   # de todas las señales bajistas, cuántas acertaron
    recall: Optional[float] = None      # de todas las bajadas reales, cuántas detectó
    f1: Optional[float] = None
    tasa_falsos_positivos: Optional[float] = None  # FP / (FP + TN): señales bajistas falsas sobre lo que no bajó
    tasa_falsos_negativos: Optional[float] = None  # FN / (FN + TP): bajadas que pasó por alto
    especificidad: Optional[float] = None

    def __post_init__(self):
        self.precision = self.tp / (self.tp + self.fp) if (self.tp + self.fp) else None
        self.recall = self.tp / (self.tp + self.fn) if (self.tp + self.fn) else None
        # F1 = 2TP / (2TP + FP + FN): 0 cuando hay errores y ningún acierto; N/D solo sin casos.
        denominador_f1 = 2 * self.tp + self.fp + self.fn
        self.f1 = 2 * self.tp / denominador_f1 if denominador_f1 else None
        self.tasa_falsos_positivos = self.fp / (self.fp + self.tn) if (self.fp + self.tn) else None
        self.tasa_falsos_negativos = self.fn / (self.fn + self.tp) if (self.fn + self.tp) else None
        self.especificidad = self.tn / (self.tn + self.fp) if (self.tn + self.fp) else None


@dataclass
class MetricasAuditoria:
    n_evaluadas: int = 0
    exactitud_direccional: Optional[float] = None
    exactitud_balanceada: Optional[float] = None
    referencia_mayoritaria: Optional[float] = None      # acierto si siempre predijera la clase más frecuente
    matriz: Optional[pd.DataFrame] = None               # filas = real, columnas = predicha
    por_clase: Optional[pd.DataFrame] = None           # precision / recall / f1 / soporte por clase
    bajista: MetricasBajista = field(default_factory=MetricasBajista)
    distribucion_real: Optional[pd.Series] = None
    distribucion_predicha: Optional[pd.Series] = None


def _asegurar_columnas(df: pd.DataFrame) -> pd.DataFrame:
    """Garantiza las columnas 'predicha' y 'real' normalizadas, venga del cargador o de un DataFrame crudo."""
    if "predicha" in df.columns and "real" in df.columns:
        return df
    if "direccion_predicha" not in df.columns or "direccion_real" not in df.columns:
        return df
    d = df.copy()
    if "predicha" not in d.columns:
        d["predicha"] = d["direccion_predicha"].map(normalizar_direccion)
    if "real" not in d.columns:
        d["real"] = d["direccion_real"].map(normalizar_direccion)
    return d


def calcular_metricas(df: pd.DataFrame, clase_positiva: str = CLASE_POSITIVA) -> MetricasAuditoria:
    """Calcula todas las métricas de auditoría sobre filas ya evaluadas (real conocida)."""
    m = MetricasAuditoria()
    df = _asegurar_columnas(df)
    if df.empty or "predicha" not in df.columns:
        return m
    df = df.dropna(subset=["predicha", "real"])
    m.n_evaluadas = len(df)
    if df.empty:
        return m

    aciertos = int((df["predicha"] == df["real"]).sum())
    m.exactitud_direccional = aciertos / m.n_evaluadas

    es_pos = df["predicha"] == clase_positiva
    es_pos_real = df["real"] == clase_positiva
    m.bajista = MetricasBajista(
        tp=int((es_pos & es_pos_real).sum()),
        fp=int((es_pos & ~es_pos_real).sum()),
        fn=int((~es_pos & es_pos_real).sum()),
        tn=int((~es_pos & ~es_pos_real).sum()),
    )

    clases_presentes = [c for c in CLASES if c in set(df["real"]) | set(df["predicha"])]
    matriz = pd.crosstab(df["real"], df["predicha"])
    matriz = matriz.reindex(index=clases_presentes, columns=clases_presentes, fill_value=0)
    m.matriz = matriz

    filas = []
    recalls = []
    for clase in clases_presentes:
        tp_c = int(((df["predicha"] == clase) & (df["real"] == clase)).sum())
        fp_c = int(((df["predicha"] == clase) & (df["real"] != clase)).sum())
        fn_c = int(((df["predicha"] != clase) & (df["real"] == clase)).sum())
        soporte = int((df["real"] == clase).sum())
        precision = tp_c / int((df["predicha"] == clase).sum()) if int((df["predicha"] == clase).sum()) else None
        recall = tp_c / soporte if soporte else None
        f1 = (
            2 * tp_c / (2 * tp_c + fp_c + fn_c)
            if (2 * tp_c + fp_c + fn_c) > 0
            else None
        )
        filas.append({
            "clase": clase, "precision": precision, "recall": recall, "f1": f1,
            "predicciones": int((df["predicha"] == clase).sum()), "casos_reales": soporte,
        })
        if recall is not None:
            recalls.append(recall)
    m.por_clase = pd.DataFrame(filas).set_index("clase")
    m.exactitud_balanceada = float(np.mean(recalls)) if recalls else None

    conteo_real = df["real"].value_counts()
    m.referencia_mayoritaria = conteo_real.max() / m.n_evaluadas
    m.distribucion_real = conteo_real.reindex(CLASES).dropna()
    m.distribucion_predicha = df["predicha"].value_counts().reindex(CLASES).dropna()
    return m


def metricas_por_periodo(df: pd.DataFrame, freq: str = "MS") -> pd.DataFrame:
    """Exactitud y métricas bajistas agrupadas por período (usa la fecha del resultado)."""
    df = _asegurar_columnas(df)
    if df.empty or "predicha" not in df.columns:
        return pd.DataFrame()
    df = df.copy()
    df["fecha_objetivo"] = pd.to_datetime(df["fecha_objetivo"], errors="coerce")
    df = df.dropna(subset=["fecha_objetivo"])
    grupo = df.set_index("fecha_objetivo").resample(freq)
    filas = []
    for periodo, g in grupo:
        if g.empty:
            continue
        m = calcular_metricas(g.reset_index(drop=True))
        filas.append({
            "periodo": periodo,
            "observaciones": m.n_evaluadas,
            "exactitud": m.exactitud_direccional,
            "precision_bajista": m.bajista.precision,
            "deteccion_bajadas": m.bajista.recall,
            "falsos_positivos_bajista": m.bajista.fp,
        })
    return pd.DataFrame(filas).set_index("periodo")


def exactitud_movil(df: pd.DataFrame, ventana: int = 20) -> pd.DataFrame:
    """Exactitud direccional móvil ordenada por fecha de resultado."""
    df = _asegurar_columnas(df)
    if df.empty or "predicha" not in df.columns:
        return pd.DataFrame()
    d = df.copy()
    d["fecha_objetivo"] = pd.to_datetime(d["fecha_objetivo"], errors="coerce")
    d = d.dropna(subset=["fecha_objetivo"])
    d = d.sort_values("fecha_objetivo").set_index("fecha_objetivo")
    acierto = (d["predicha"] == d["real"]).astype(float)
    return pd.DataFrame({
        "exactitud_movil": acierto.rolling(ventana, min_periods=min(5, ventana)).mean(),
        "aciertos_acumulados": acierto.expanding().mean(),
        "observaciones": acierto.expanding().count(),
    })


def exactitud_acumulada(periodos: pd.DataFrame) -> pd.Series:
    """Exactitud acumulada ponderada por número de observaciones de cada período.

    No es el promedio simple de porcentajes mensuales: un mes con 1 acierto en 1 señal
    no pesa igual que otro con 0 de 9.
    """
    if periodos.empty or "exactitud" not in periodos.columns:
        return pd.Series(dtype=float)
    aciertos = periodos["exactitud"].fillna(0) * periodos["observaciones"]
    total = periodos["observaciones"].cumsum()
    return (aciertos.cumsum() / total.replace(0, np.nan)).where(total > 0)


def calibracion_probabilidades(df: pd.DataFrame, n_bins: int = 5) -> Optional[pd.DataFrame]:
    """Si existe prob_bajista válida, compara probabilidad emitida vs bajada realizada por bin."""
    if "prob_bajista" not in df.columns or df.empty:
        return None
    d = df.dropna(subset=["prob_bajista"])
    d = d[(d["prob_bajista"] >= 0) & (d["prob_bajista"] <= 1)]
    if d.empty:
        return None
    bins = pd.cut(d["prob_bajista"], bins=n_bins, include_lowest=True)
    tabla = d.groupby(bins, observed=True).agg(
        observaciones=("prob_bajista", "size"),
        prob_media=("prob_bajista", "mean"),
        tasa_bajada_real=("real", lambda s: float((s == "bajista").mean())),
    ).reset_index(drop=True)
    return tabla
